/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import config.Koneksi;
/**
 *
 * @author Asus
 */
public class Main {
    public static void main(String[] args) {

        Koneksi.getKoneksi();

    }
}
